package com.marcosfshirafuchi.hroauth.dto;
public record RoleDTO(Long id, String roleName) {
}