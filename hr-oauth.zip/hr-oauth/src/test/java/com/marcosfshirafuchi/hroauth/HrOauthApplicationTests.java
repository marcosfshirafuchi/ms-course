package com.marcosfshirafuchi.hroauth;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

class HrOauthApplicationTests {

    @Test
    void sanity() {
        // Teste leve, não sobe contexto do Spring
        assertTrue(true);
    }
}


